import { test, expect ,request } from "@playwright/test";

test("Authenticate with cred and use Get method", {tag:'@smoke'},async({})=>{

    const apiResponse = await request.newContext({baseURL:'https://api.qaautomationlabs.com/v1/'})
   const authenticatedResponse = await apiResponse.post('auth/login',{data:{
        "email": "qa@demo.io",
  "password": "Password123"
    }})
     expect(authenticatedResponse.status()).toBe(201)


})
